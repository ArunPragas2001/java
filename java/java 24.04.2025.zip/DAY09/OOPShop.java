class Item{
 String description;
 int unitprice;
Item (String desc,int unitPrice )
}

class Basket{
	item itm[5];
	void addItem(Item i){
		
	}
	
	void calculateprice(){
	};
	
	
}


class ShopDemo{
	public static void main(String[]arg){
		
		basket basket1=new basket();
		char input='y';
		do{
			String desc=sc.nextLine();
			int up=sc.nextInt();
			new Item(desc,up);
			i++;
		}
		while()
			
			
	}