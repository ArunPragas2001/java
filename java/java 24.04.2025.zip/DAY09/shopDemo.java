import java.util.Scanner;
class shopDemo{

    static String description[]={"Bread","Milk Powder","Tooth paste"};
	static int unitPrice[]={160,1060,260};
	static Scanner sc=new Scanner(System.in);
	static byte [] itemBasketIndexQuantity new byte[3];
    static int item basketQuantity=m 	
	
	
	
	
	static void getItems(){
            System.out.println("welcome to the Demo shop");
			System.out.println("Please select your item by entering the number");
			char userOption='y';
			do{
				
            for(int i=0; i<description.length;i++){
				 System.out.println("Enter"+i+"for"+description[i]);
			}
				  System.out.println("Enter y to continue,press any charactor to exit");
				  int otem
				  userOption=sc.nextline().charAt(0);//(char)
            }	
          			
	}
	 while(userOption=='y');
	}
	 
	public static void main(String args[]){
		getItems();
		
	}




}